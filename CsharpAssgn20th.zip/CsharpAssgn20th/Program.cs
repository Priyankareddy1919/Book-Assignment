﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpAssgn20th

{
    class Books
    {
        public int Id;
        public string bookName, authorName, descriptionOfBook;
        public float price;

        public Books(int id, string bookName, string authorName, string descriptionOfBook, float price)
        {
            this.Id = id;
            this.bookName = bookName;
            this.authorName = authorName;
            this.descriptionOfBook = descriptionOfBook;
            this.price = price;
        }

        public override string ToString()
        {
            return $" BookId : {Id}; Books Name : {bookName}; Author Name : {authorName}; Book Description : {descriptionOfBook}; price:{price};";
        }
    }
    internal class Program
    {
        static void displayBook(List<Books> arr)
        {
            foreach (Books item in arr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {

            List<Books> bookList = new List<Books>{

                new Books(101, "My Journey","Dr. A.P.J. Abdul Kalam","motivational book", 500),
                new Books(102, "Dr. Bibek Debroy","Making of New India","motivational book", 1000),
                new Books(103, "I Have a Dream"," Rashmi Bansal","inspirational book", 1500),
                new Books(104, "You are Born to Blossom","Dr APJ Abdul Kalam","inspirational book", 2500),
                new Books(105, "The Monk Who Sold His Ferrari","Robin Sharma","inspirational book", 5500),

            };
            displayBook(bookList);

            Console.WriteLine("Press 1 : Edit the Book ");
            Console.WriteLine("Press 2 : Delete the Book");
            Console.WriteLine("Press 3 : Add  the book ");
            Console.WriteLine("Press 4 : show discription");
            Console.WriteLine("press 5 : display the book details");

            int num = 0;
            //Console.WriteLine();
            Console.WriteLine("Enter number according to your display choice");
            num = int.Parse(Console.ReadLine());
            if( num<=0 || num > 5)
            {
                //num = int.Parse(Console.ReadLine());
                Console.WriteLine("please enter a number between 1 to 5");
            }
            

            switch (num)
            {
                case 1:

                    Console.WriteLine("Press 1 : Edit the Book name ");
                    Console.WriteLine("Press 2 : Edit the Book author  ");
                    Console.WriteLine("Press 3 : Edit the Book description  ");
                    Console.WriteLine("Press 4 : Edit the Book price  ");

                    Console.WriteLine("enter the book id");
                    int bookId = int.Parse(Console.ReadLine());
                    int bookindex = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == bookId)
                        {
                            bookindex = bookList.IndexOf(item);

                        }
                    }


                    Console.WriteLine("Enter number according to edit");
                    int selectedNum = int.Parse(Console.ReadLine());

                    switch (selectedNum)
                    {
                        case 1:
                            Console.WriteLine("enter the book name");
                            string nameOfBook = Console.ReadLine();

                            bookList[bookindex].bookName = nameOfBook;

                            break;

                        case 2:
                            Console.WriteLine("enter the book author");
                            string authorOfBook = Console.ReadLine();

                            bookList[bookindex].authorName = authorOfBook;
                            break;
                        case 3:
                            Console.WriteLine("enter the book description");
                            string bookDescription = Console.ReadLine();

                            bookList[bookindex].descriptionOfBook = bookDescription;
                            break;
                        case 4:
                            Console.WriteLine("enter the book price");
                            float bookprice = float.Parse(Console.ReadLine());

                            bookList[bookindex].price = bookprice;
                            break;

                    }

                    Console.WriteLine("The edited book details");
                    Console.WriteLine(bookList[bookindex]);
                    break;
                case 2:
                    //int deletedindex = 0;
                    Console.WriteLine("Enter the Id of book You  want to delete");
                    int deleteId = int.Parse(Console.ReadLine());
                    int deletedindex = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == deleteId)
                        {
                            deletedindex = bookList.IndexOf(item);
                            Console.WriteLine(deletedindex);

                        }
                    }
                    bookList.RemoveAt(deletedindex);
                    displayBook(bookList);

                    break;
                case 3:

                    Console.WriteLine("how many books You want to add");
                    int n = int.Parse(Console.ReadLine());

                    for (int i = 1; i <= n; i++)
                    {
                        Console.WriteLine("Enter the book  Details You  want to Add");
                        Console.WriteLine("Enter the Bookname");
                        string bookName = Console.ReadLine();

                        Console.WriteLine("Enter the AuthorName");
                        string authorName = Console.ReadLine();

                        Console.WriteLine("Enter the description");
                        string descriptionOfBook = Console.ReadLine();

                        Console.WriteLine("Enter the Price");
                        float price;
                        bool result = Single.TryParse(Console.ReadLine(), out price);

                        if (result)
                        {
                            bookList.Add(new Books(bookList.Count + 1, bookName, authorName, descriptionOfBook, price));

                        }
                    }
                    displayBook(bookList);
                    break;

                case 4:

                    Console.WriteLine("showing description of book");
                    Console.WriteLine("enter the id you want to show description");
                    int showId = int.Parse(Console.ReadLine());
                    int index1 = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == showId)
                        {
                            index1 = bookList.IndexOf(item);

                        }
                        
                    }
                    Console.WriteLine(bookList[index1].descriptionOfBook);
                    break;

                case 5:


                    Console.WriteLine("showing display of book");
                    Console.WriteLine("enter the bookid you want to display");
                    int showId1 = int.Parse(Console.ReadLine());
                    int index2 = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == showId1)
                        {
                            index2 = bookList.IndexOf(item);

                        }
                    }
                    Console.WriteLine(bookList[index2]);
                    break;
            }//switch
            Console.ReadLine();
        }

    }
}
/* 
  	In .net -- perform the same operations
  	  1. Edit the book
	  2. Delete 
	  3. Add
	  4. Show description
	  5. Display
	  6. Exit
*/