myApp.controller("bookDisplayController",function($scope,bookManage){

    $scope.bookArr=bookManage.getAllBookDetails();
    $scope.addNewBooks=false;
    $scope.showAddNewBookEventHandler=function(){
       $scope.addNewBooks=true;
    }
    $scope.showEditBook=false;
    $scope.editBookDetailsEventHandler=function(book){
        $scope.selectedBook=book;
        alert("U have selected BookId :"+ book.bookId + " to edit");
        $scope.showEditBook=true;
     }
   
     $scope.deleteBookEventHandler=function(book){
        bookManage.deleteBook(book);
     }
})


