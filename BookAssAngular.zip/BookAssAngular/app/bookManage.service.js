myApp.service("bookManage",function(){
    this.bookDetails=[{imageurl:'image1.jpg',bookId:1,bookName:"i can and i will",Author:"Antonio Robins",price:300,Description:"...."},
                    { imageurl:'image2.jpg',bookId:2,bookName:"one life one chance",Author:"Antonio Robins",price:200,Description:"...."},
                    { imageurl:'image3.jpg',bookId:3,bookName:"365 days of positive thinking",Author:"jenny kellett",price:400,Description:"...."},
                    { imageurl:'image5.jpg',bookId:4,bookName:"Think like a Monk",Author:"jay shetty",price:400,Description:"...."}];
    this.getAllBookDetails=function(){
        return this.bookDetails;
    }
   
    this.addBook=function(book)
    {
        this.bookDetails.push(book);
    }

    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    }
})
